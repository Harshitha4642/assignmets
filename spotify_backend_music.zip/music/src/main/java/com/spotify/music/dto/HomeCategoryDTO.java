package com.spotify.music.dto;

import lombok.Data;

@Data
public class HomeCategoryDTO {
	
	private String name;
	private String link;

}
