package com.spotify.music.dto;

import lombok.Data;

@Data
public class AddSongDTO {
	private String username;
	private String songname;
}
