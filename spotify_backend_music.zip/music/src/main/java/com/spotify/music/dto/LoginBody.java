package com.spotify.music.dto;

import lombok.Data;

@Data
public class LoginBody {
	  private String username;
	    private String password;
}
