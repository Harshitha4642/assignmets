package com.spotify.music.dto;

import lombok.Data;

@Data
public class HomeSongDTO {
	private String name;
	private String movie;
	private String link;
}
