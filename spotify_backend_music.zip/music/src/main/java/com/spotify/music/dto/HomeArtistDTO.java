package com.spotify.music.dto;

import lombok.Data;

@Data
public class HomeArtistDTO {
	private String name;
	private String link;

}
