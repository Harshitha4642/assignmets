package com.spotify.music.dto;

import lombok.Data;

@Data
public class Status {
	private String libStatus;

}
