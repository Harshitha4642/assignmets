package com.spotify.music.entity;

public class LikedSongs {
	

}
