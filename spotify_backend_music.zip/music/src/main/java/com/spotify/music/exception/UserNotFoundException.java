package com.spotify.music.exception;

public class UserNotFoundException extends Exception {
	public UserNotFoundException(String s){
		super(s);
	}
}
