package com.spotify.music.dto;

import lombok.Data;

@Data
public class TokenDTO {
	private String token;
	private String username;

}
