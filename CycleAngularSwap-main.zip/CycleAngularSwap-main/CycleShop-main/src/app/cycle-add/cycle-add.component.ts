import { Component } from '@angular/core';

@Component({
  selector: 'app-cycle-add',
  templateUrl: './cycle-add.component.html',
  styleUrls: ['./cycle-add.component.css']
})
export class CycleAddComponent {

}
