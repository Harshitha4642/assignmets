export interface Cycle {
    id: number;
    brand: string;
    numBorrowed:number,
    stock:number
  }