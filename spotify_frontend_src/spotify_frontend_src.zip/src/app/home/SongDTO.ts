export interface SongDTO{
    songName : string;
    movieName: string;
    artistName: string;
    link: string;
}