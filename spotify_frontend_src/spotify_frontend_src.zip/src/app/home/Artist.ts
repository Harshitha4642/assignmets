export interface Artist{
    name: string;
    link: string;
}