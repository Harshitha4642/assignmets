export interface Category{
    name: string;
    link: string;
}