export interface Song {
    name: string;
    movie: string;
    link: string;
}